const scanButton = document.querySelector('#scan-button');
const activityButton = document.querySelector('#activity-button');
const toast = document.querySelector('#toast');
let toastTimer;

function showToast(message) {
  window.clearTimeout(toastTimer);
  toast.textContent = message;
  toast.classList.add('is-visible');
  toastTimer = window.setTimeout(() => toast.classList.remove('is-visible'), 3200);
}

scanButton.addEventListener('click', () => {
  scanButton.disabled = true;
  scanButton.textContent = 'Scanning...';
  window.setTimeout(() => {
    scanButton.disabled = false;
    scanButton.textContent = 'Run security scan';
    showToast('Security scan completed. No critical issues found.');
  }, 1200);
});

activityButton.addEventListener('click', () => {
  showToast('You are viewing the latest activity.');
});
