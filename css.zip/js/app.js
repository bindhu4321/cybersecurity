
const findings = [
    {
        id: "F-001",
        name: "Security Headers Review",
        severity: "Medium",
        status: "Open"
    },
    {
        id: "F-002",
        name: "Input Validation Review",
        severity: "Low",
        status: "Open"
    },
    {
        id: "F-003",
        name: "Parameterized SQL Review",
        severity: "High",
        status: "Resolved"
    },
    {
        id: "F-004",
        name: "XSS Output Escaping Review",
        severity: "High",
        status: "Open"
    }
];

const $ = (selector) => document.querySelector(selector);

function renderFindings(filter = "") {

    const rows = $("#findingRows");

    rows.innerHTML = "";

    findings
        .filter(f =>
            `${f.id} ${f.name} ${f.severity} ${f.status}`
                .toLowerCase()
                .includes(filter.toLowerCase())
        )
        .forEach(f => {

            const row = document.createElement("tr");

            row.innerHTML = `
                <td>${f.id}</td>
                <td>${f.name}</td>
                <td>${f.severity}</td>
                <td>${f.status}</td>
                <td>
                    <button data-id="${f.id}">
                        ${f.status === "Resolved" ? "Reopen" : "Resolve"}
                    </button>
                </td>
            `;

            rows.appendChild(row);

        });

    updateMetrics();
}

function updateMetrics() {

    const open = findings.filter(f => f.status !== "Resolved").length;
    const resolved = findings.filter(f => f.status === "Resolved").length;

    $("#openCount").textContent = String(open).padStart(2, "0");

    $("#resolvedCount").textContent = resolved + 18;
}

$("#findingRows").addEventListener("click", (event) => {

    const id = event.target.dataset.id;

    if (!id) return;

    const item = findings.find(f => f.id === id);

    if (!item) return;

    item.status =
        item.status === "Resolved"
            ? "Open"
            : "Resolved";

    renderFindings($("#search").value);

});

$("#search").addEventListener("input", (event) => {

    renderFindings(event.target.value);

});

$("#scanForm").addEventListener("submit", (event) => {

    event.preventDefault();

    const authorized = $("#authorized").value;

    if (authorized !== "yes") {

        $("#output").textContent =
            "Scan blocked. Confirm authorization first.";

        return;
    }

    const target = $("#targetUrl").value;

    $("#output").textContent =
        `Simulation completed for ${target}. No live requests were sent. Review and document verified evidence manually.`;

    $("#scanCount").textContent =
        Number($("#scanCount").textContent) + 1;

});

$("#themeBtn").addEventListener("click", () => {

    const light =
        document.documentElement.dataset.theme === "light";

    document.documentElement.dataset.theme =
        light ? "dark" : "light";

    $("#themeBtn").textContent =
        light ? "🌙" : "☀️";

});

document.querySelectorAll("[data-target]").forEach(button => {

    button.addEventListener("click", () => {

        document.querySelector(button.dataset.target)
            .scrollIntoView({
                behavior: "smooth"
            });

    });

});

$("#exportBtn").addEventListener("click", () => {

    const report = `
SecApp Pro VAPT Summary

Author: Bindhu Sri

Scope: Authorized local training application

Note: Replace demonstration data with verified evidence.
`;

    const blob = new Blob([report], {
        type: "text/plain"
    });

    const url = URL.createObjectURL(blob);

    const anchor = document.createElement("a");

    anchor.href = url;

    anchor.download = "secapp-vapt-summary.txt";

    anchor.click();

    URL.revokeObjectURL(url);

});

renderFindings();