from pathlib import Path

from flask import Flask, Response, render_template, request

app = Flask(__name__)

BASE_DIR = Path(__file__).resolve().parent
REPORT_TEMPLATE_PATH = BASE_DIR / "vapt_report_template.md"


def sanitize_text(value: str) -> str:
    return (value or "N/A").strip() or "N/A"


def render_report(data: dict) -> str:
    template = REPORT_TEMPLATE_PATH.read_text(encoding="utf-8")

    replacements = {
        "app_name": sanitize_text(data.get("app_name", "")),
        "owner": sanitize_text(data.get("owner", "")),
        "environment": sanitize_text(data.get("environment", "")),
        "scope": sanitize_text(data.get("scope", "")),
        "severity": sanitize_text(data.get("severity", "")),
        "summary": sanitize_text(data.get("summary", "")),
        "date": sanitize_text(data.get("date", "")),
        "findings": sanitize_text(data.get("findings", "")),
        "recommendations": sanitize_text(data.get("recommendations", "")),
    }

    formatted = template
    for key, value in replacements.items():
        formatted = formatted.replace(f"{{{{ {key} }}}}", value)
    return formatted


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        data = {
            "app_name": request.form.get("app_name", ""),
            "owner": request.form.get("owner", ""),
            "environment": request.form.get("environment", ""),
            "scope": request.form.get("scope", ""),
            "severity": request.form.get("severity", ""),
            "summary": request.form.get("summary", ""),
            "date": request.form.get("date", "") or "2026-09-18",
            "findings": request.form.get("findings", ""),
            "recommendations": request.form.get("recommendations", ""),
        }
        report = render_report(data)
        return render_template("index.html", data=data, report=report, generated=True)

    return render_template("index.html", generated=False, data={}, report="")


@app.route("/download", methods=["POST"])
def download_report():
    data = {
        "app_name": request.form.get("app_name", ""),
        "owner": request.form.get("owner", ""),
        "environment": request.form.get("environment", ""),
        "scope": request.form.get("scope", ""),
        "severity": request.form.get("severity", ""),
        "summary": request.form.get("summary", ""),
        "date": request.form.get("date", "") or "2026-09-18",
        "findings": request.form.get("findings", ""),
        "recommendations": request.form.get("recommendations", ""),
    }
    report = render_report(data)
    filename = f"{sanitize_text(data['app_name']).replace(' ', '_').lower()}_vapt_report.md"
    return Response(
        report,
        mimetype="text/markdown",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
