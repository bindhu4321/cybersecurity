# SecApp-Pro

SecApp-Pro is a lightweight Flask application for preparing and exporting a VAPT-style security assessment report. It provides a simple form for collecting project details and turns the input into a markdown report that can be reviewed or downloaded.

## Features

- Form-based security assessment intake
- Dynamic markdown report generation
- Downloadable VAPT report output
- Clean responsive interface

## Project Structure

```text
SecApp-Pro/
├── app.py
├── requirements.txt
├── README.md
├── vapt_report_template.md
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## Setup

1. Open a terminal in the project folder.
2. Create a virtual environment if needed.
3. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Start the app:

```bash
python app.py
```

5. Open the browser at:

```text
http://127.0.0.1:5000/
```

## Usage

- Enter the application name, owner, environment, risk level, scope, summary, findings, and remediation recommendations.
- Submit the form to generate the VAPT report preview.
- Use the download button to save the report as a markdown file.

## Notes

This project is intended as a starter tool for internal security assessments and can be expanded to include automated scanner integration, PDF export, or database storage.
